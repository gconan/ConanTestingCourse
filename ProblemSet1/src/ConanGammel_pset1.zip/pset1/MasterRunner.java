package pset1;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
   SLListAddTester.class,
   SLListRepOkTester.class,
   HashCodeTester.class,
   EqualsTester.class
})

public class MasterRunner {

	

}
